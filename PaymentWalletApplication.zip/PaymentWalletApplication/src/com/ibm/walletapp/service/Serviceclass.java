package com.ibm.walletapp.service;

import java.sql.Connection;
import java.sql.SQLException;

import com.ibm.walletapp.bean.*;
import com.ibm.walletapp.dao.*;

public class Serviceclass implements ServiceInterface{
	
	
	Daoclass dao=new Daoclass();
	
	@Override
	public void DaoclassConn() throws SQLException
	{
		dao.DaoclassConn();
	}
	@Override
	public void CreateAccount(CustomerDetails ref) throws SQLException{
		 dao.CreateAccount(ref);
	}
	
	@Override
	public void Deposit(CustomerDetails ref) throws SQLException
	{
		dao.Deposit(ref);
	}
	/*@Override
	public void Deposit(String ContactNo,int amount) throws SQLException
	{
		dao.Deposit(ContactNo,amount);
	} */
	
	@Override
	public String Withdraw(CustomerDetails ref) throws SQLException
	{
		return dao.Withdraw(ref);
	}
	
	@Override
	public void Transfer(CustomerDetails ref) throws SQLException
	{
		dao.Transfer(ref);
	}
	
	@Override
	public String PassBook(CustomerDetails ref) throws SQLException
	{
		return dao.PassBook(ref);
	}
	
	@Override
	public String CheckBalance(CustomerDetails ref) throws SQLException
	{
		return dao.CheckBalance(ref);
	}
	
	@Override
	public boolean login(CustomerDetails ref) throws SQLException
	{
		return dao.login(ref);
	}
	

}


