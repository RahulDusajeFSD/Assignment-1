package com.ibm.walletapp.bean;

public class CustomerDetails {
	
	
	private String name;
	private int AccountNo;
	private String Address;
	private String ContactNo;
	private int age;
	private int Pin;
	
	
	
	
	public CustomerDetails(String contactNo) {
		ContactNo = contactNo;
	}
	


	public CustomerDetails(String contactNo, int pin, int age) {
		super();
		ContactNo = contactNo;
		this.age = age;
		Pin = pin;
	}



	public CustomerDetails(String contactNo, int pin) {
		//super();
		ContactNo = contactNo;
		Pin = pin;
	}



	public CustomerDetails(String contactNo,String toContact,int amount) {
		ContactNo = contactNo;
		this.amount = amount;
		ToContact = toContact;
	}
	
	
	public int getPin() {
		return Pin;
	}
	public void setPin(int pin) {
		Pin = pin;
	}
	public CustomerDetails(String name, int age, String ContactNo, String Address, int Pin) {
		super();
		this.name = name;
		this.age = age;
		this.ContactNo = ContactNo;
		this.Address = Address;
		this.Pin=Pin;
		
		
	}
	public long getDeposit() {
		return Deposit;
	}
	public void setDeposit(int deposit) {
		Deposit = deposit;
	}
	public int getAmount() {
		return amount;
	}
	public void setAmount(int amount) {
		this.amount = amount;
	}
	public String getToContact() {
		return ToContact;
	}
	public void setToContact(String toContact) {
		ToContact = toContact;
	}
	public long getWithdraw() {
		return Withdraw;
	}
	public void setWithdraw(long withdraw) {
		Withdraw = withdraw;
	}
	public long getFundTransfer() {
		return FundTransfer;
	}
	public void setFundTransfer(long fundTransfer) {
		FundTransfer = fundTransfer;
	}
	public String getTransaction() {
		return Transaction;
	}
	public void setTransaction(String transaction) {
		Transaction = transaction;
	}
	private int Deposit;
	private int amount;
	private String ToContact;
	private long Withdraw;
	private long FundTransfer;
	private String Transaction;
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getAccountNo() {
		return AccountNo;
	}
	public void setAccountNo(int accountNo) {
		AccountNo = accountNo;
	}
	public String getAddress() {
		return Address;
	}
	public void setAddress(String address) {
		Address = address;
	}
	public String getContactNo() {
		return ContactNo;
	}
	public void setContactNo(String contactNo) {
		ContactNo = contactNo;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	
	
	

}
