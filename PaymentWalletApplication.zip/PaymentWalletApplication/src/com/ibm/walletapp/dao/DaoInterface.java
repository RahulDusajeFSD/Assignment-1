package com.ibm.walletapp.dao;

import java.sql.Connection;
import java.sql.SQLException;

import com.ibm.walletapp.bean.*;
public interface DaoInterface {
	
	
	public void DaoclassConn() throws SQLException;
	public void CreateAccount(CustomerDetails ref) throws SQLException;
	//public void MakingConnection(Connection dbCon) throws SQLException;
	//public void Deposit(String ContactNo,int amount) throws SQLException;
	
	public void Deposit(CustomerDetails ref) throws SQLException;
	
	public String Withdraw(CustomerDetails ref)throws SQLException;
	public void Transfer(CustomerDetails ref)throws SQLException;
	public String PassBook(CustomerDetails ref)throws SQLException;
	public String CheckBalance(CustomerDetails ref) throws SQLException;
	public boolean login(CustomerDetails ref) throws SQLException;
	
	

}
