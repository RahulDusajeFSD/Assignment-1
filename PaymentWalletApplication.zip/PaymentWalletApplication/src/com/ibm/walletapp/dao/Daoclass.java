package com.ibm.walletapp.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.*;

import com.ibm.walletapp.bean.CustomerDetails;

public class Daoclass implements DaoInterface{
	
	Connection dbCon;
	
	
	Date date=new Date();
 public void DaoclassConn() throws SQLException {
	
	
	
		dbCon = DriverManager.getConnection("jdbc:mysql://localhost:3306/bankaccountdetails?serverTimezone=IST", "root", "");
		
	
	
}
	


	
	
	PreparedStatement pstmt; 
	
	
	
	
	
	
	
	
	@Override
	public void CreateAccount(CustomerDetails ref) throws SQLException{
		
		String insertQry = "insert into basicdetails(Name,Age,ContactNo,Address,PIN,Time) values(?,?,?,?,?,?)";
		String accQry="insert into balancedetails(contactNo) values(?)";
		
			String d1=date.toString();
			pstmt = dbCon.prepareStatement(insertQry);
			pstmt.setString(1,ref.getName());
			pstmt.setInt(2,ref.getAge());
			pstmt.setString(3, ref.getContactNo());
			pstmt.setString(4, ref.getAddress());
			pstmt.setInt(5, ref.getPin());
			pstmt.setString(6, d1);
		
		
				pstmt.executeUpdate();
					
			PreparedStatement pstmt1;
			pstmt1 = dbCon.prepareStatement(accQry);
			pstmt1.setString(1, ref.getContactNo());
			pstmt1.executeUpdate();
		
	
		
	}
	
public void Deposit(CustomerDetails ref) throws SQLException
	{
		String depositQry="Update balancedetails set Balance=Balance+? where ContactNo=?";
		
			pstmt = dbCon.prepareStatement(depositQry);
			pstmt.setInt(1, ref.getAmount());
			pstmt.setString(2,ref.getContactNo());
			
			pstmt.executeUpdate();
				
	
	
	} 

public String Withdraw(CustomerDetails ref) throws SQLException
{
	String checkQry="select Balance from balancedetails where ContactNo=?";
	String withdrawQry="Update balancedetails set Balance=Balance-? where ContactNo=?";
		pstmt = dbCon.prepareStatement(checkQry);
		pstmt.setString(1, ref.getContactNo());
		
		
		ResultSet rs = pstmt.executeQuery();
		
		
		while(rs.next())
		{
			if(rs.getInt("Balance")<1000)
			{
				return "Low Balance";
			}
			else
			{
					pstmt=dbCon.prepareStatement(withdrawQry);
					
					pstmt.setInt(1,ref.getAmount());
					pstmt.setString(2, ref.getContactNo());
					
					pstmt.executeUpdate();
					
				}
			}
		
		return "Balance Withdrawn Successfully";
		}

	

public void Transfer(CustomerDetails ref) throws SQLException
{
	//using basic details
	//String acc1Qry="insert into transactiontable(ContactNo) values(?)";
	String transferQry="insert into transactiontable(ContactNo,FromUser,ToUser,Time, Amount) values(?,?,?,?,?)";
	String transferAmtQryUs="Update balancedetails set balance=balance+? where ContactNo=?"; 
	String transferAmtQryTo="Update balancedetails set balance=balance-? where ContactNo=?"; 
	
	
	
	Date t=new Date();
	
		PreparedStatement pstmt3;
		pstmt3=dbCon.prepareStatement(transferQry);
		pstmt3.setString(1, ref.getContactNo());
		pstmt3.setString(2, ref.getContactNo());
		pstmt3.setString(3, ref.getToContact());
		String currTime= t.toString();
		pstmt3.setString(4,currTime);
		pstmt3.setInt(5, ref.getAmount());
		
		pstmt3.executeUpdate();
		
	
		PreparedStatement pstmt4;
		pstmt4=dbCon.prepareStatement(transferAmtQryUs);
		pstmt4.setInt(1, ref.getAmount());
		pstmt4.setString(2, ref.getToContact());
		
		pstmt4.executeUpdate();
		
	
		PreparedStatement pstmt5;
		pstmt5=dbCon.prepareStatement(transferAmtQryTo);
		pstmt5.setInt(1,ref.getAmount());
		pstmt5.setString(2, ref.getContactNo());
		
		pstmt5.executeUpdate();
			
}
	

public String PassBook(CustomerDetails ref) throws SQLException
{
	String op="";
	String passbookQry="select FromUser,ToUser,Time,Amount from transactiontable where ContactNo=?";
	
	pstmt=dbCon.prepareStatement(passbookQry);
			
	pstmt.setString(1, ref.getContactNo());
	ResultSet rs = pstmt.executeQuery();
	
	
	while(rs.next())
	{
		op="From\n"+rs.getString("FromUser")+"\nTo\n"+rs.getString("ToUser")+"\nTime\n"+rs.getString("Time")+"\nAmount\n"+rs.getInt("Amount");
	}
			return op;
	}

public String CheckBalance(CustomerDetails ref) throws SQLException
{
	String balanceQry="Select Balance from balancedetails where ContactNo=?";
	
	pstmt=dbCon.prepareStatement(balanceQry);
	
	pstmt.setString(1, ref.getContactNo());
	ResultSet rs=pstmt.executeQuery();
	String op2="";
	while(rs.next())
	{
	//System.out.println("Balance:"+ rs.getInt("Balance"));
	op2="Balance:\n"+rs.getInt("Balance");
	return op2;
	}
	
	return "Balance Checked Successfully";
}

public void login(CustomerDetails ref, ) throws SQLException
{
	String loginQry="select ContactNo, PIN from basicdetails where ContactNo=? and PIN=?";
	
	pstmt=dbCon.prepareStatement(loginQry);
	
	pstmt.setString(1, ref.getContactNo());
	pstmt.setInt(2, ref.getPin());
	
	ResultSet rs=pstmt.executeQuery();
	
	if(rs.next()==false)
		return false;
	
	return true;
}




}




