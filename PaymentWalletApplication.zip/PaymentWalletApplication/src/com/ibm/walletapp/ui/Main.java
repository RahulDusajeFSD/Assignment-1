package com.ibm.walletapp.ui;

import java.sql.Connection;

import com.ibm.walletapp.service.*;
import com.ibm.walletapp.bean.CustomerDetails;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.*;

public class Main{

	public static void main(String[] args) {
		
		Scanner scan= new Scanner(System.in);
		
		ServiceInterface service=
				new Serviceclass();
		

try
{
	service.DaoclassConn();
}
catch(SQLException e)
{
	e.printStackTrace();
}
		
		//rs.next()==false
		int option=0;
		while(option!=5)
        {
			int h=0;
		System.out.println("You must sign in to proceed");
		System.out.println("Enter 10 digit Registered ContactNo and 4 digit PIN");
	//	System.out.println("Press 1 to proceed");
		
		String i=scan.nextLine();
		//scan.nextLine(); 
		int y=scan.nextInt();
		scan.nextLine(); 
		CustomerDetails c7=new CustomerDetails(i,y);
		
		try
		{
			if(!service.login(c7))
			{
				System.out.println("You must REGISTER to proceed.");
				System.out.println();
				System.out.println();
				
				
			}
			else
			{
			
			
	    	
			System.out.println("Welcome to Payment Wallet Application");
			System.out.println("Press 1 to create Bank Account:");
	    	System.out.println("Press 2 to Deposit to bank acoount:");
	    	System.out.println("Press 3 to Withdraw from bank account:");
	    	System.out.println("Press 4 to Transfer Fund:");
	    	System.out.println("Press 5 to Print PassBook");
	    	System.out.println("Press 6 to Check Balance");
	    	System.out.println("Press 7 to exit");
	    	
	    	System.out.println("Enter your choice");
	    	
	    	option = scan.nextInt();
	    	scan.nextLine();
	    	
	    	switch(option){
			case 1:
				System.out.println("Enter name");
				String name=scan.nextLine();
				
				System.out.println("Enter Age");
				int age=scan.nextInt();
				
				scan.nextLine();
				
				System.out.println("Enter Contact Number");
				String Cno=scan.nextLine();
				
				System.out.println("Enter Address");
				String Addrs=scan.nextLine();
				
				System.out.println("Enter 4 digit Pin");
				int pin=scan.nextInt();
				scan.nextLine();
				
				
				CustomerDetails c=new CustomerDetails(name, age, Cno, Addrs, pin);
				//CustomerDetails cc=new CustomerDetails(name, age, Cno, Addrs, pin);
				
				try {
					
					service.CreateAccount(c);
				}catch(SQLException e)
				{
					System.out.println("Could not create account");
				}
								
					break;
		 case 2:
					System.out.println("Enter Contact Number");
					String ww=scan.nextLine();
					System.out.println("Enter Deposit amount");
					int ff=scan.nextInt();
					CustomerDetails c2=new CustomerDetails(ww,ff);
					try
					{
						service.Deposit(c2);
					//service.Deposit(ww,ff);
					}
					catch(SQLException e)
					{
						System.out.println("Failure in deposit");
					}
					break;
			case 3:
				System.out.println("Enter Contact Number");
				String ww1=scan.nextLine();
				System.out.println("Enter amount to withdraw");
				int ff1=scan.nextInt();
				
				CustomerDetails c3=new CustomerDetails(ww1,ff1);
				try
				{
				String out=service.Withdraw(c3);
				System.out.println(out);
				}
				catch(SQLException e)
				{
					System.out.println("Failure in withdraw");
				}
				break;
				
				
				
			case 4:
					System.out.println("Enter Contact Number to transfer amount");
					String tosend=scan.nextLine();
					System.out.println("Enter your contact number");
					String our=scan.nextLine();
					System.out.println("Enter Amount to transfer");
					int am=scan.nextInt();
					
					
					CustomerDetails c4=new CustomerDetails(tosend,our,am);

					try
					{
					service.Transfer(c4);
					}
					catch(SQLException e)
					{
						System.out.println("Failure in Transfer");
					}
					break;
				
					
			case 5:
					System.out.println("Enter your Contact Number");
					String g=scan.nextLine();
					
					CustomerDetails c5=new CustomerDetails(g);
					try
					{
					String out=service.PassBook(c5);
					System.out.println(out);
					}catch(SQLException e)
					{
						System.out.println("Failure in Printing passbook");
					}
					break;
					
			case 6:
				System.out.println("Enter your Contact Number");
				String g1=scan.nextLine();
				
				CustomerDetails c6= new CustomerDetails(g1);
				try
				{
				String out =service.CheckBalance(c6);
				System.out.println(out);
				}catch(SQLException e)
				{
					System.out.println("Failure in Getting Balance");
				}
				break;		
					
			case 7: System.exit(0);
					
			default:continue;	
			
					} 
		
	    	
		
	        }
			}catch(SQLException e)
		{
				System.out.println("Failure");
			}
			
		}
		
	
	
		
	}
}

    	
		
       
	
		
	

