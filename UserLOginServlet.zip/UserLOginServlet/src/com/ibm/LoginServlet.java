package com.ibm;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet("/LoginServlet")
public class LoginServlet extends HttpServlet {

	PreparedStatement pstmt;
	Connection dbCon;
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		
		response.setContentType("text/html");
		final HttpSession session=request.getSession();
		try
		{
			Class.forName("com.mysql.jdbc.Driver");
		 dbCon = DriverManager.getConnection("jdbc:mysql://localhost:3306/userloginsystem?serverTimezone=IST", "root", "");
	//response.getWriter().println("Connected");
		System.out.println("Connected");
		}
		catch(SQLException e)
		{
			//response.getWriter().println("Not Connected");
			System.out.println("Not connected" + e.getMessage());
		}
		//response.getWriter().append("Served at: ").append(request.getContextPath());
 catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			System.out.println("Driver issues: " + e.getMessage());
		}
		
		
		
		String uname=request.getParameter("UserName_Login");	
		String password=request.getParameter("Password_Login");
		
		
		String checkQry="select UserName,Password from credentials where UserName=? and Password=?";
	
		try
		{
		pstmt=dbCon.prepareStatement(checkQry);
		
		pstmt.setString(1, uname);
		pstmt.setString(2,password);
		
		ResultSet rs=pstmt.executeQuery();
		
//		if(uname.equals(rs.getString("UserName")) && password.equals(rs.getString("Password")))
//		
//			{
//			System.out.println("Valid user");
			
			
	if(rs.next()==true)
		
	{
		session.setAttribute("UserName_Login",uname);
		
		
	
	
PrintWriter out=response.getWriter();
//	
	out.println("Welcome:"+uname);
//	
	/*String str1="<!DOCTYPE html>\r\n" + 
			"<html>\r\n" + 
			"<head>\r\n" + 
			"<meta charset=\"ISO-8859-1\">\r\n" + 
			"<title>Insert title here</title>\r\n" + 
			"</head>\r\n" + 
			"<body>\r\n" + 
			"\r\n" + 
			"\r\n" + 
			"\r\n" + 
			"<form action=\"LogoutServlet\" method=\"post\">\r\n" + 
			"    <input type=\"submit\" value=\"Logout\" />\r\n" + 
			"\r\n" + 
			" \r\n" + 
			"\r\n" + 
			"</body>\r\n" + 
			"</html>";
	
	out.println(str1); */
	
	response.sendRedirect("ActiveLogin");
	}
	
	else
	{
		PrintWriter out=response.getWriter();
		out.println("Create Account first");
		out.println();
		
		RequestDispatcher dispatcher=request.getRequestDispatcher("login.html");
	
		dispatcher.include(request, response);
	}
	
			
		
		} 
		catch(SQLException e)
		{
			e.printStackTrace();
		}
		
		
	}

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	
		doPost(request, response);
	} 

}
