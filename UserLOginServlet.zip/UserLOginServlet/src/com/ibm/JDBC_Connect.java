package com.ibm;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class JDBC_Servlet
 */
@WebServlet("/JDBC_Connect")
public class JDBC_Connect extends HttpServlet {
	
	PreparedStatement pstmt;
	Connection dbCon;
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
			// TODO Auto-generated method stub
		//response.getWriter().append("Served at: ").append(request.getContextPath());

		
		try
		{
			Class.forName("com.mysql.jdbc.Driver");
		 dbCon = DriverManager.getConnection("jdbc:mysql://localhost:3306/userloginsystem?serverTimezone=IST", "root", "");
	//response.getWriter().println("Connected");
		System.out.println("Connected");
		}
		catch(SQLException e)
		{
			//response.getWriter().println("Not Connected");
			System.out.println("Not connected" + e.getMessage());
		}
		//response.getWriter().append("Served at: ").append(request.getContextPath());
 catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			System.out.println("Driver issues: " + e.getMessage());
		}
		
		String uname=request.getParameter("UserName");	
		String password=request.getParameter("Password");
		
		String insertQry="insert into credentials(UserName,Password) values(?,?)";
		try
		{
			pstmt=dbCon.prepareStatement(insertQry);
			pstmt.setString(1, uname);
			pstmt.setString(2, password);
			
			if(pstmt.executeUpdate()>0)
				System.out.println("Inserted successfully");
			else
				System.out.println("problem with insertion");
		}catch(SQLException e)
		{
			e.printStackTrace();
		}
		
		response.sendRedirect("index.html");
		
		
		
	}
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	//response.getWriter().append("Served at: ").append(request.getContextPath());

		
		doGet(request,response);
	}
	


	}

