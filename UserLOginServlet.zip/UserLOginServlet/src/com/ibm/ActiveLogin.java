package com.ibm;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class ActiveLogin
 */
@WebServlet("/ActiveLogin")
public class ActiveLogin extends HttpServlet {
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//response.getWriter().append("Served at: ").append(request.getContextPath());
	
		
		if(request.getSession().getAttribute("UserName_Login")==null)
			response.sendRedirect("index.html");
		
		
		response.setContentType("text/html");
		
		
	
	PrintWriter out=response.getWriter();
	
	out.println("Welcome User:" + request.getSession().getAttribute("UserName_Login"));
	
	
	
	String str1="<!DOCTYPE html>\r\n" + 
			"<html>\r\n" + 
			"<head>\r\n" + 
			"<meta charset=\"ISO-8859-1\">\r\n" + 
			"<title>Insert title here</title>\r\n" + 
			"</head>\r\n" + 
			"<body>\r\n" + 
			"\r\n" + 
			"<p> You would get to see this page if and only if you're registered with us</p>\r\n" + 
			"\r\n" + 
			"\r\n" + 
			"<form action=\"LogoutServlet\" method=\"post\">\r\n" + 
			"    <input type=\"submit\" value=\"Logout\" />\r\n" + 
			"\r\n" + 
			" \r\n" + 
			"\r\n" + 
			"</body>\r\n" + 
			"</html>";
	
	out.println(str1);
	
	
	}

}
