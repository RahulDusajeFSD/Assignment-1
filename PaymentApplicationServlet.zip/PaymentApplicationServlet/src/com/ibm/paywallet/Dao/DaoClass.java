package com.ibm.paywallet.Dao;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.util.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
//import java.util.Date;

import com.ibm.paywallet.bean.CustomerDetails;

public class DaoClass {
	
	
	
	
	Connection dbCon;
	PreparedStatement pstmt; 
	PreparedStatement pstmt1; 
	PreparedStatement pstmt2;
	PreparedStatement pstmt3;
	String f;
	
	Date date=new Date();
	
	public DaoClass()
	{
	 	try
	 	{
	 		Class.forName("com.mysql.cj.jdbc.Driver");
		dbCon = DriverManager.getConnection("jdbc:mysql://localhost:3306/walletservlet?serverTimezone=IST", "root", "");
		//System.out.println("Connected");
	 	}
	 	catch(SQLException e)
	 	{
	 		System.out.println("Can't connect to db : " + e.getMessage());
	 	} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	
	}
	
public void CreateAccount(CustomerDetails c, HttpServletResponse response)
{
		String insertQry = "insert into basicdetails(Name,Age,contactNo,PIN,Address) values(?,?,?,?,?)";
		String accQry="insert into balancedetails(PIN) values(?)";
		
			//String d1=date.toString();
		try
		{
			//Object n=request.getSession().getAttribute("object");
			//CustomerDetails c= (CustomerDetails) n;
			//System.out.println(c + "Trying to execute query");
			pstmt = dbCon.prepareStatement(insertQry);
			pstmt.setString(1,c.getName());
			pstmt.setString(2,c.getAge());
			pstmt.setString(3, c.getContactNo());
			pstmt.setString(4, c.getPin());
			pstmt.setString(5, c.getAddress());
			
			pstmt1=dbCon.prepareStatement(accQry);
			pstmt1.setString(1, c.getPin());
			
			
		
				pstmt1.executeUpdate();
				pstmt.executeUpdate();
				System.out.println("User Added Successfully!!");
				response.sendRedirect("Dashboard.jsp");   // dashboard me sign in ka option....wrna sbse pehle create account exit
				
		}catch(SQLException |IOException e)
		{
		System.out.println(e.getMessage());
		}
		
		
}

public void login(CustomerDetails c, HttpServletResponse response, HttpServletRequest request, HttpSession session)
{

	String checkQry="select Name,PIN from basicdetails where Name=? and PIN=?";

	try
	{
		String uname=request.getParameter("NameServlet");	
		String pin=request.getParameter("PINServlet");
		
	pstmt=dbCon.prepareStatement(checkQry);
	
	pstmt.setString(1, uname);
	pstmt.setString(2,pin);
	
	ResultSet rs=pstmt.executeQuery();
		
if(rs.next()==true)
	
{
	response.sendRedirect("options.jsp");  // baaki ke options
	session.setAttribute("NameServlet", uname);
	session.setAttribute("PINServlet", pin);


}

else
{
	PrintWriter out=response.getWriter();
	out.println("You entered wrong Name or PIN");
	out.println();		
	RequestDispatcher dispatcher=request.getRequestDispatcher("LoginJSP.jsp");

	dispatcher.forward(request, response);
}

		
	
	} 
	catch(SQLException | IOException |ServletException e)
	{
		System.out.println(e.getMessage());
	}
	
	
}
public void deposit(CustomerDetails c, HttpServletResponse response, HttpServletRequest request)
{
	
	
	 String gg=(String)request.getSession().getAttribute("PINServlet");
	String depositQry="update balancedetails set Balance=Balance+? where PIN=?";
	
	try
	{
	pstmt=dbCon.prepareStatement(depositQry);
	pstmt.setInt(1, c.getAmount());
	pstmt.setString(2, gg);
	pstmt.executeUpdate();
	response.sendRedirect("options.jsp");
	}catch(SQLException | IOException e)
	{
		System.out.println(e.getMessage());
	}
	
	
	
}

public void withdraw(CustomerDetails c, HttpServletResponse response, HttpServletRequest request)
{
	
	
	 String gg=(String)request.getSession().getAttribute("PINServlet");
	 String checkQry="select Balance from balancedetails where PIN=?";
	String withdrawQry="update balancedetails set Balance=Balance-? where PIN=?";
	
	try
	{
	pstmt=dbCon.prepareStatement(checkQry);
	pstmt.setString(1,gg);
	
	ResultSet rs=pstmt.executeQuery();
	while(rs.next())
	{
	if(rs.getInt("Balance")<1000)
	{
		System.out.println("Low Balance");
		response.sendRedirect("options.jsp");
	}
	else
	{
	pstmt1=dbCon.prepareStatement(withdrawQry);
	pstmt1.setInt(1, c.getAmount());
	pstmt1.setString(2, gg);
	pstmt1.executeUpdate();
	response.sendRedirect("options.jsp");
	}
	}
	}catch(SQLException | IOException e)
	{
		System.out.println(e.getMessage());
	}
	
	
	
}



public void TransferFund(CustomerDetails c, HttpServletResponse response, HttpServletRequest request)
{
	
	
	 String gg=(String)request.getSession().getAttribute("PINServlet");
	 String ggto=c.getPin();
	 String checkQry="select Balance from balancedetails where PIN=?";
	String withdrawQry="update balancedetails set Balance=Balance-? where PIN=?";
	String withdrawQry1="update balancedetails set Balance=Balance+? where PIN=?";
	String insertTransaction="insert into transactiontable(FromUser,ToUser,Amount,Date) values(?,?,?,?)";
	
	try
	{
	pstmt=dbCon.prepareStatement(checkQry);
	pstmt.setString(1,gg);
	
	ResultSet rs=pstmt.executeQuery();
	while(rs.next())
	{
	if(rs.getInt("Balance")<1000)
	{
		System.out.println("Low Balance");
		response.sendRedirect("options.jsp");
	}
	else
	{
	pstmt1=dbCon.prepareStatement(withdrawQry);
	pstmt1.setInt(1, c.getAmount());
	pstmt1.setString(2, gg);
	
	pstmt2=dbCon.prepareStatement(withdrawQry1);
	
	
	pstmt2.setInt(1,c.getAmount());
	pstmt2.setString(2, gg);
	pstmt1.executeUpdate();
	pstmt2.executeUpdate();
	
	String d=date.toString();
	pstmt3=dbCon.prepareStatement(insertTransaction);
	pstmt3.setString(1,gg);
	pstmt3.setString(2,ggto);
	pstmt3.setInt(3,c.getAmount());
	pstmt3.setString(4,d);
	
	pstmt1.executeUpdate();
	pstmt2.executeUpdate();
	pstmt3.executeUpdate();
	response.sendRedirect("options.jsp");
	}
	}
	}catch(SQLException | IOException e)
	{
		System.out.println(e.getMessage());
	}
	
	
	
	
}

public void printPassbook(HttpServletResponse response, HttpServletRequest request,HttpSession session)
{
	
	
	 String gg=(String)request.getSession().getAttribute("PINServlet");
	String passbookQry="select * from transactiontable where FromUser=?";
	
	try
	{
	pstmt=dbCon.prepareStatement(passbookQry);

	pstmt.setString(1, gg);
	ResultSet rs =pstmt.executeQuery();
	
	while(rs.next())
	{
		f="To:"+rs.getString("ToUser")+"\nAmount"+rs.getInt("Amount")+"\nTime:"+rs.getString("Date");
	}
	
	session.setAttribute("passbook", f);
	
	response.sendRedirect("printPassBook.jsp");
	}catch(SQLException | IOException e)
	{
		System.out.println(e.getMessage());
	}
	
	
	
}

}
