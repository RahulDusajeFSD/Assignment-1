package com.ibm.walletSpringCore.Wallet;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.ibm.walletSpring.ui.common;
//import com.ibm.walletSpring.ui.walletSpringUI;

public class App 
{
    public static void main( String[] args )
    {
       
    	ClassPathXmlApplicationContext context=new ClassPathXmlApplicationContext("appContext.xml");
    	
    	common wallet=(common)context.getBean("UI", common.class);
    	
    	
    	
    	//common c=new common();
    	wallet.selection();
    	
    }
}
