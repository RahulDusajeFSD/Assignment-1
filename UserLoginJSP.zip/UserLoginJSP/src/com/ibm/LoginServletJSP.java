package com.ibm;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet("/LoginServletJSP")
public class LoginServletJSP extends HttpServlet {

	PreparedStatement pstmt;
	Connection dbCon;
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		
		response.setContentType("text/html");
		final HttpSession session=request.getSession();
		try
		{
			Class.forName("com.mysql.jdbc.Driver");
		 dbCon = DriverManager.getConnection("jdbc:mysql://localhost:3306/userloginjsp?serverTimezone=IST", "root", "");

		}
		catch(SQLException e)
		{
			e.getMessage();
		}
		
        catch (ClassNotFoundException e) {
			e.getMessage();
		}
		
		
		
		
		
		String checkQry="select UserName,Password from jspcred where UserName=? and Password=?";
	
		try
		{
			String uname=request.getParameter("UserName_Login");	
			String password=request.getParameter("Password_Login");
			
		pstmt=dbCon.prepareStatement(checkQry);
		
		pstmt.setString(1, uname);
		pstmt.setString(2,password);
		
		ResultSet rs=pstmt.executeQuery();
			
	if(rs.next()==true)
		
	{
		response.sendRedirect("successLogin.jsp");
		session.setAttribute("UserName_Login", uname);	
	
	
}
	
	else
	{
		PrintWriter out=response.getWriter();
		out.println("Create Account first");
		out.println();		
		RequestDispatcher dispatcher=request.getRequestDispatcher("loginJSP.jsp");
	
		dispatcher.include(request, response);
	}
	
			
		
		} 
		catch(SQLException e)
		{
			e.getMessage();
		}
		
		
	}

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	
		doPost(request, response);
	} 

}
