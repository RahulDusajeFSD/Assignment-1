package com.ibm;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
@WebServlet("/RegisterJsp")
public class RegisterJsp extends HttpServlet {
	
	PreparedStatement pstmt;
	Connection dbCon;
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		
		
		
		try
		{
			Class.forName("com.mysql.jdbc.Driver");
		 dbCon = DriverManager.getConnection("jdbc:mysql://localhost:3306/userloginjsp?serverTimezone=IST", "root", "");	
		
		}catch(SQLException e)
		{
			
			e.getMessage();
		}
		catch(ClassNotFoundException e)
		{
		
			e.getMessage();
		}
		
		String insertQry="insert into jspcred(UserName,Password) values(?,?)";
		String uname=request.getParameter("UserName");	
		String password=request.getParameter("Password");
		
		try
		{
			
			pstmt=dbCon.prepareStatement(insertQry);
			pstmt.setString(1, uname);
			pstmt.setString(2, password);
			
			pstmt.executeUpdate();
			
		}
		catch(SQLException e)
		{
			e.getMessage();
		}
		
		response.sendRedirect("index.html");
		
		
		
	}
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		doGet(request,response);
	}
	


	}

